ALTER TABLE customer_db.verification_logs 
    ADD COLUMN iban_entity_id BIGINT;

ALTER TABLE customer_db.verification_logs
    ADD CONSTRAINT fk_verification_logs_iban_entity
        FOREIGN KEY (iban_entity_id) REFERENCES customer_db.iban_requests (id);

ALTER TABLE customer_db.verification_logs
    ADD CONSTRAINT uq_verification_logs_iban_entity_id UNIQUE (iban_entity_id);





ALTER TABLE customer_db.csat_survey ADD COLUMN reference_number VARCHAR(255);