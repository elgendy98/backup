INSERT INTO lookup_db.plans
(id, plan_code, plan_name, plan_name_ar, active, product_id, plan_description, plan_description_ar, plan_order, notes, metadata)
VALUES(105, 'PLAN_009', 'Travel Insurance', 'تأمين السفر', 1, 1, NULL, NULL, 0, NULL, NULL);


INSERT INTO lookup_db.plan_covers
(id, coverCode, cover_name, cover_name_ar, cover_desc, cover_desc_ar, claim_requirements, claim_requirements_ar, plan_id, metadata, provider)
VALUES(20013, 'TRAV', 'Travel Coverage', 'تغطية السفر', NULL, NULL, NULL, NULL, 105, NULL, NULL);


INSERT INTO lookup_db.plan_benefits
(benefit_code, benefit_name, benefit_name_ar, sum_insured, sum_insured_desc, benefit_excess, benefit_desc, benefit_desc_ar, benefit_bubble_desc, cover_id, sub_benefits, `order`)
VALUES('TR11', 'Medical Emergency Expenses', 'الطوارئ الطبية', 150000, 'SAR 150,000.00', '200 SAR will be deducted of each claim before your insurance kicks in', 'Medical emergency coverage protects you from significant expenses related to unforeseen medical issues, accidents, or injuries. that need emergency medical &/or surgical treatment while you are traveling outside of KSA. Typically hospital stays, surgeries, doctor visits, prescription medications, diagnostic tests, etc. are covered within specified limits. Coverage conditions and exclusions apply.', 'تغطية الطوارئ الطبية تحميك من النفقات الكبيرة المتعلقة بالمشاكل الطبية غير المتوقعة، والحوادث، أو الإصابات التي تتطلب علاجًا طبيًا و/أو جراحيًا عاجلًا أثناء سفرك خارج المملكة العربية السعودية. عادةً ما يتم تغطية الإقامات في المستشفيات، والجراحات، وزيارات الأطباء، والأدوية الموصوفة، والفحوصات التشخيصية، إلخ ضمن حدود محددة. تنطبق شروط التغطية والاستثناءات.', NULL, 20013, NULL, NULL);