INSERT INTO lookup_db.lookup
(created_at, lookup_key, source, updated_at, value_ar, value_en, lookup_type_id) VALUES
(NOW(), 'OTP-999', 'OTP', null, 'انتهت صلاحية رمز التحقق', 'OTP has expired', 1),
(NOW(), 'OTP-777', 'OTP', null, 'تم إدخال رمز تحقق غير صحيح', 'Incorrect OTP entered', 1),
(NOW(), 'OTP-888', 'OTP', null, 'لقد تجاوزت الحد الأقصى لعدد محاولات إدخال رمز التحقق. يرجى المحاولة مرة أخرى لاحقًا', 'You have exceeded the maximum number of verification code attempts. Please try again later', 1);
(NOW(), 'OTP-222', 'OTP', null, 'يرجى الانتظار قليلاً قبل طلب رمز تحقق جديد', 'Please wait a moment before requesting a new code ', 1),

INSERT INTO lookup_db.lookup
(created_at, lookup_key, source, updated_at, value_ar, value_en, lookup_type_id) VALUES
(NOW(), 'TREE-G-001', 'GENERAL-INSURANCE', null, 'حدث خطأ ما', 'Something went wrong', 1),
(NOW(), 'TREE-HI-002', 'GENERAL-INSURANCE', null, 'يجب أن تكون العمر 18 عامًا أو أكثر', 'Age must be 18 or older.', 1),
(NOW(), 'TREE-HI-400', 'GENERAL-INSURANCE', null, 'لا يمكن تعديل عرض الأسعار الآن', 'Quote cannot be modified now.', 1),
(NOW(), 'TREE-HUB-006', 'GENERAL-INSURANCE', null, 'المستخدم غير مخول للوصول إلى هذا المورد', 'User is not authorized to access this resource.', 1),
(NOW(), 'TREE-HUB-005', 'GENERAL-INSURANCE', null, 'حالة OTP غير صالحة', 'Invalid OTP status.', 1),
(NOW(), 'TREE-HUB-003', 'GENERAL-INSURANCE', null, 'لم يتم اختيار الخطة بعد، يرجى اختيار الخطة أولاً', 'Plan is not chosen yet, please choose plan first.', 1),
(NOW(), 'TREE-HUB-002', 'GENERAL-INSURANCE', null, 'تم إصدار هذه الوثيقة بالفعل', 'This policy is already issued.', 1),
(NOW(), 'TREE-HUB-001', 'GENERAL-INSURANCE', null, 'نوع دمج غير مدعوم', 'Not supported merge type.', 1),
(NOW(), 'TREE-HI-05', 'GENERAL-INSURANCE', null, 'يجب أن تكون تاريخ بدء الوثيقة بعد اليوم', 'Policy Start date should be after today.', 1),
(NOW(), 'TREE-TRV-001', 'GENERAL-INSURANCE', null, 'لا يمكن أن تتجاوز فترة الوثيقة 180 يومًا', 'Policy period cannot exceed 180 days.', 1),
(NOW(), 'TREE-TRV-002', 'GENERAL-INSURANCE', null, 'تاريخ الانتهاء يجب أن يكون بعد تاريخ السريان', 'Expiry date cannot be before effective date', 1),
(NOW(), 'TREE-HI-003', 'GENERAL-INSURANCE', null, 'عملية الدفع غير صالحة', 'Not Valid Payment', 1),
(NOW(), 'TREE-HI-004', 'GENERAL-INSURANCE', null, 'تم إجراء الدفع مسبقاً', 'payment already done before', 1),
(NOW(), 'TREE-HI-005', 'GENERAL-INSURANCE', null, 'حدث خطأ أثناء جلب بيانات تجديد الوثيقة', 'get policy renewal error', 1);


INSERT INTO lookup_db.lookup
(created_at, lookup_key, source, updated_at, value_ar, value_en, lookup_type_id) VALUES
(NOW(), 'TREE-MOTOR-021', 'GENERAL-INSURANCE', null, 'يوجد ملحق مُصدر مسبقًا لهذه الوثيقة', 'An issued endorsement for this policy already exist', 1),
(NOW(), 'TREE-MOTOR-022', 'GENERAL-INSURANCE', null, 'الملحق غير موجود', 'Endorsement not found', 1),
(NOW(), 'TREE-MOTOR-023', 'GENERAL-INSURANCE', null, 'غير مصرح لك بتنفيذ هذا الإجراء', 'Not authorized', 1),
(NOW(), 'TREE-MOTOR-024', 'GENERAL-INSURANCE', null, 'تاريخ السريان غير صحيح', 'Invalid effective date', 1),
(NOW(), 'TREE-MOTOR-026', 'GENERAL-INSURANCE', null, 'بيانات غير صحيحة', 'Invalid data', 1);
