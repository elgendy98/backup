CREATE TABLE tree_integration.crm_policy_consumer_master (
    id BIGINT NOT NULL AUTO_INCREMENT,
    policy_no VARCHAR(255) UNIQUE,
    crm_request LONGTEXT ,
    created_at DATETIME DEFAULT NULL,
    
    PRIMARY KEY (id)
);

CREATE TABLE tree_integration.crm_policy_consumer_sub_master (
    id BIGINT NOT NULL AUTO_INCREMENT,
    id_number VARCHAR(255) DEFAULT NULL,
    policy_no VARCHAR(255) UNIQUE,
    product_code VARCHAR(50) DEFAULT NULL,
    channel_code VARCHAR(100) DEFAULT NULL,
    operations JSON,
    created_at DATETIME DEFAULT NULL,
    
    PRIMARY KEY (id)
);

CREATE INDEX idx_crm_policy_consumer_sub_master_created_at
    ON tree_integration.crm_policy_consumer_sub_master(created_at);


CREATE TABLE tree_integration.customer_operation_details (
    id BIGINT NOT NULL AUTO_INCREMENT,
    customer_response LONGTEXT,
    status VARCHAR(50),
    crm_sub_master_id BIGINT,

    PRIMARY KEY (id),

    CONSTRAINT fk_customer_operation_policy_no
        FOREIGN KEY (crm_sub_master_id)
        REFERENCES crm_policy_consumer_sub_master(id)
);


CREATE TABLE tree_integration.push_notification_operation_details (
    id BIGINT NOT NULL AUTO_INCREMENT,
    notification_response LONGTEXT,
    status VARCHAR(50),
    success_notification_count INT,
    failed_notification_count INT,
    crm_sub_master_id BIGINT,

    PRIMARY KEY (id),

    CONSTRAINT fk_push_notification_operation_policy_no
        FOREIGN KEY (crm_sub_master_id)
        REFERENCES crm_policy_consumer_sub_master(id)
);


CREATE TABLE tree_integration.medallia_operation_details (
    id BIGINT NOT NULL AUTO_INCREMENT,
    medallia_response LONGTEXT,
    status VARCHAR(50),
    pushed_at DATETIME DEFAULT NULL,
    crm_sub_master_id BIGINT,

    PRIMARY KEY (id),

    CONSTRAINT fk_medallia_operation_policy_no
        FOREIGN KEY (crm_sub_master_id)
        REFERENCES crm_policy_consumer_sub_master(id)
);


INSERT INTO lookup_db.lookup
(created_at, lookup_key, source, updated_at, value_ar, value_en, lookup_type_id)
VALUES
    (NOW(), 'motor_afterSales_title', 'Notification', null, 'دربك خضر💚', 'Hello!', 2),
    (NOW(), 'trv_afterSales_title', 'Notification', null, 'نتمنى لك رحلة ممتعة وآمنة ✈️', 'Have a Safe and Lovely Trip✈️', 2),
    (NOW(), 'pet_afterSales_title', 'Notification', null, 'تطمّن 🐾', 'Hello!', 2),
    (NOW(), 'medmal_afterSales_title', 'Notification', null, 'يا هلا!', 'Hello!', 2),
    (NOW(), 'dwh_afterSales_title', 'Notification', null, 'يا هلا!', 'Hello!', 2),
    (NOW(), 'dwc_afterSales_title', 'Notification', null, 'يا هلا!', 'Hello!', 2),
    (NOW(), 'ipi_afterSales_title', 'Notification', null, 'يا هلا!', 'Hello!', 2),
    (NOW(), 'hi_afterSales_title', 'Notification', null, 'جعله بيت عامر  🏠', 'Hello!', 2),
    (NOW(), 'gtk_afterSales_title', 'Notification', null, 'الله يديم عليك الصحة و العافية 💚', 'Hello!', 2),
    (NOW(), 'motor_afterSales_body', 'Notification', null, 'وثيقة تأمين سيارتك برقم %s فعّالة من %s إلى %s', 'Your Motor insurance policy number %s is valid from %s to %s.', 2),
    (NOW(), 'trv_afterSales_body', 'Notification', null, 'وثيقة تأمين سفرك رقم %s فعّالة من %s إلى %s.', 'Your travel insurance policy, policy number %s, is valid from %s to %s.', 2),
    (NOW(), 'pet_afterSales_body', 'Notification', null, 'وثيقة تأمين %s رقم %s فعّالة من %s إلى %s.', 'Just to reassure you, %s’s insurance policy number %s is valid from %s to %s.', 2),
    (NOW(), 'medmal_afterSales_body', 'Notification', null, 'وثيقتك لتأمين الأخطاء الطبية برقم %s فعّالة من %s إلى %s.', 'Your medical malpractice insurance policy number %s is active from %s to %s.', 2),
    (NOW(), 'dwh_afterSales_body', 'Notification', null, 'وثيقة التأمين الصحي لعمالتك المنزلية رقم %s صارت مفعّلة.', 'Your domestic worker health insurance policy is now active, policy number %s.', 2),
    (NOW(), 'dwc_afterSales_body', 'Notification', null, 'وثيقة تأمين عقد العمالة المنزلية برقم %s صارت جاهزة 💚', 'Your domestic worker’s contract policy number %s has been issued 💚', 2),
    (NOW(), 'ipi_afterSales_body', 'Notification', null, 'وثيقتك لحماية دخلك برقم %s أصدرت وفعّالة من %s إلى %s 💚', 'Your Income Protection insurance policy number %s has been issued and is active from %s to %s.', 2),
    (NOW(), 'hi_afterSales_body', 'Notification', null, 'وثيقة تأمينك الصحي برقم %s فعّالة من %s إلى %s.', 'Your home insurance policy number %s is valid from %s to %s. 💚', 2),
    (NOW(), 'gtk_afterSales_body', 'Notification', null, 'وثيقتك لتأمين المنزل رقم %s فعّالة من %s إلى %s.', 'Your health insurance policy, policy number %s, is valid from %s to %s.', 2);




CREATE TABLE Identity_db.user_device (
    id BIGINT NOT NULL AUTO_INCREMENT,
    device_id VARCHAR(255) UNIQUE,
    device_token VARCHAR(255) UNIQUE,
    created_at datetime,
    updated_at datetime,
    user_id BIGINT unsigned,
    
    CONSTRAINT pk_user_device PRIMARY KEY (id),
    CONSTRAINT fk_user_device_on_user FOREIGN KEY (user_id) REFERENCES Identity_db.users (id)
);

CREATE TABLE Identity_db.user_device_history (
    id BIGINT NOT NULL AUTO_INCREMENT,
    device_id VARCHAR(255) DEFAULT NULL,
    device_token VARCHAR(255) NOT NULL,
    history_data JSON, 
    
    CONSTRAINT uk_user_device_history_device_id UNIQUE (device_id),
    CONSTRAINT uk_user_device_history_device_token UNIQUE (device_token),
    CONSTRAINT pk_user_device_history PRIMARY KEY (id)
);




INSERT INTO Identity_db.user_device (
    device_token,
    user_id,
    created_at,
    updated_at
)
SELECT
    u.device_token,
    u.id,
    NOW(),
    NOW()
FROM Identity_db.users u
WHERE u.device_token IS NOT NULL
  AND TRIM(u.device_token) <> '';




SELECT device_token, COUNT(*)
FROM users
WHERE device_token IS NOT NULL
  AND TRIM(device_token) <> ''
GROUP BY device_token
HAVING COUNT(*) > 1;



SELECT COUNT(*)
FROM users
WHERE device_token IS NOT NULL
  AND TRIM(device_token) <> '';


SELECT COUNT(*)
FROM user_device;